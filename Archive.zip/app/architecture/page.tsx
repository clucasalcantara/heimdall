"use client";

import {
  Activity,
  AlertTriangle,
  Brain,
  Clock,
  GitBranch,
  Shield,
  Target,
  TrendingUp,
  Zap,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import { Badge } from "@/components/ui/badge";
import { DashboardHeader } from "@/components/dashboard-header";
import { DashboardShell } from "@/components/dashboard-shell";
import type React from "react";

export default function ArchitecturePage() {
  return (
    <DashboardShell>
      {/* header */}
      <DashboardHeader
        heading="Sistema de Antifraude Inteligente"
        subheading="Arquitetura técnica e estratégias de implementação para o desafio Reborn"
      />

      {/* quick badges */}
      <div className="mb-6 flex flex-wrap items-center gap-2">
        <Badge variant="outline" className="bg-blue-900/20 text-blue-400">
          <Zap className="mr-1 h-3 w-3" />
          Latência &lt; 300 ms
        </Badge>
        <Badge variant="outline" className="bg-green-900/20 text-green-400">
          <Target className="mr-1 h-3 w-3" />
          Score 0-100
        </Badge>
        <Badge variant="outline" className="bg-purple-900/20 text-purple-400">
          <Shield className="mr-1 h-3 w-3" />
          Aprovar / Revisar / Bloquear
        </Badge>
      </div>

      {/* TABS */}
      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="ml">Estratégia ML</TabsTrigger>
          <TabsTrigger value="feedback">Feedback</TabsTrigger>
          <TabsTrigger value="versioning">Versionamento</TabsTrigger>
        </TabsList>

        {/* --- OVERVIEW --- */}
        <TabsContent value="overview" className="space-y-8">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">
                  <Shield className="mr-2 inline-block h-5 w-5 text-blue-400" />
                  Requisitos Técnicos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm text-gray-300">
                <div className="flex justify-between">
                  <span>Latência Máx.</span>
                  <Badge
                    className="bg-red-900/20 text-red-400"
                    variant="outline"
                  >
                    &lt; 300 ms
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Score</span>
                  <Badge
                    className="bg-blue-900/20 text-blue-400"
                    variant="outline"
                  >
                    0-100
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Decisões</span>
                  <div className="space-x-1">
                    <Badge
                      className="bg-green-900/20 text-green-400"
                      variant="outline"
                    >
                      Aprovar
                    </Badge>
                    <Badge
                      className="bg-yellow-900/20 text-yellow-400"
                      variant="outline"
                    >
                      Revisar
                    </Badge>
                    <Badge
                      className="bg-red-900/20 text-red-400"
                      variant="outline"
                    >
                      Bloquear
                    </Badge>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span>Tempo Real</span>
                  <Badge
                    className="bg-green-900/20 text-green-400"
                    variant="outline"
                  >
                    <Activity className="mr-1 h-3 w-3" />
                    Ativo
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">
                  <Brain className="mr-2 inline-block h-5 w-5 text-purple-400" />
                  Componentes Principais
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-gray-300">
                <div>• Engine de Regras (40%)</div>
                <div>• Modelo ML (60%)</div>
                <div>• Sistema de Feedback</div>
                <div>• Cold-Start Handler</div>
                <div>• Monitor de Performance</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* --- PERFORMANCE --- */}
        <TabsContent value="performance" className="space-y-8">
          <div className="grid gap-6 md:grid-cols-3">
            <KpiCard
              title="SLA Compliance"
              icon={Clock}
              value="99,5 %"
              description="Transações &lt; 300 ms"
              accent="text-green-400"
            />
            <KpiCard
              title="Throughput (TPS)"
              icon={TrendingUp}
              value="1 247"
              description="Transações por segundo"
              accent="text-blue-400"
            />
            <KpiCard
              title="Error Rate"
              icon={AlertTriangle}
              value="0,1 %"
              description="Taxa de erro total"
              accent="text-yellow-400"
            />
          </div>
        </TabsContent>

        {/* --- ML STRATEGY --- */}
        <TabsContent value="ml" className="space-y-8">
          <StrategyCard
            title="Modelo Híbrido"
            points={[
              "40 % regras determinísticas",
              "60 % modelo ML",
              "Ajuste dinâmico por feedback",
            ]}
          />
        </TabsContent>

        {/* --- FEEDBACK --- */}
        <TabsContent value="feedback" className="space-y-8">
          <StrategyCard
            title="Loop de Feedback"
            points={[
              "Coleta automática de falsos positivos",
              "Recalibração semanal dos pesos",
              "Retreinamento supervisionado",
              "Validação A/B controlada",
            ]}
          />
        </TabsContent>

        {/* --- VERSIONING --- */}
        <TabsContent value="versioning" className="space-y-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">
                <GitBranch className="mr-2 inline-block h-5 w-5 text-purple-400" />
                Versionamento de Modelo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-gray-300">
              <div>• Blue-Green deployment</div>
              <div>• Canary 10 % → 50 % → 100 %</div>
              <div>• Rollback automático</div>
              <div>• SemVer (v2.1.0 → v2.2.0-beta)</div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  );
}

/* ---------- helpers ---------- */

interface KpiCardProps {
  title: string;
  icon: React.ElementType;
  value: string;
  description: string;
  accent: string;
}
function KpiCard({
  title,
  icon: Icon,
  value,
  description,
  accent,
}: KpiCardProps) {
  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className={`text-white flex items-center ${accent}`}>
          <Icon className="mr-2 h-5 w-5" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className={`mb-1 text-3xl font-bold ${accent}`}>{value}</div>
        <p className="text-sm text-gray-400">{description}</p>
      </CardContent>
    </Card>
  );
}

interface StrategyCardProps {
  title: string;
  points: string[];
}
function StrategyCard({ title, points }: StrategyCardProps) {
  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="list-disc space-y-1 pl-5 text-sm text-gray-300">
          {points.map((p) => (
            <li key={p}>{p}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
